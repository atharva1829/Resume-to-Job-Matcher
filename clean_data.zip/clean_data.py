import pandas as pd
import re
import html
import zipfile
from pathlib import Path

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "cleaned_data"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


JOB_ZIP = BASE_DIR / "training_data.csv.zip"
RESUME_ZIP = BASE_DIR / "Resume.csv.zip"


import zipfile
import pandas as pd

def load_csv_from_zip(zip_path):
    with zipfile.ZipFile(zip_path, "r") as archive:
        csv_files = [
            name for name in archive.namelist()
            if name.lower().endswith(".csv")
        ]

        if not csv_files:
            raise ValueError(f"No CSV file found in {zip_path}")

        with archive.open(csv_files[0]) as file:
            df = pd.read_csv(file, low_memory=False)

    return df


def load_csv_from_zip(zip_path):

    with zipfile.ZipFile(zip_path, "r") as archive:

        
        csv_files = [
            name for name in archive.namelist()
            if name.lower().endswith(".csv")
        ]

        if not csv_files:
            raise ValueError("No CSV file found in ZIP")

        
        with archive.open(csv_files[0]) as file:
            df = pd.read_csv(file, low_memory=False)

    return df



jobs = load_csv_from_zip(JOB_ZIP)


resumes = load_csv_from_zip(RESUME_ZIP)


print("Jobs:", jobs.shape)
print("Resumes:", resumes.shape)

print("Job columns:", jobs.columns.tolist())
print("Resume columns:", resumes.columns.tolist())


print("\nMissing values in jobs:")
print(jobs.isnull().sum())

print("\nMissing values in resumes:")
print(resumes.isnull().sum())

print("\nDuplicate job rows:", jobs.duplicated().sum())
print("Duplicate resume rows:", resumes.duplicated().sum())


def clean_text(text):

    
    if pd.isna(text):
        return ""

    
    text = str(text)

   
    text = html.unescape(text)

   
    text = re.sub(r"<[^>]+>", " ", text)

    
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)

    
    text = text.lower()

   
    text = re.sub(r"[^a-z0-9+#.\s]", " ", text)

    
    text = re.sub(r"\s+", " ", text).strip()

    return text




jobs = jobs.drop_duplicates().copy()


jobs["job_description"] = jobs["job_description"].fillna("")


jobs["job_description"] = jobs["job_description"].apply(clean_text)


jobs["position_title"] = jobs["position_title"].fillna("")
jobs["position_title"] = jobs["position_title"].apply(clean_text)


jobs = jobs[
    jobs["job_description"].str.len() > 0
].copy()


jobs["description_length"] = jobs["job_description"].str.len()


jobs.to_csv(
    OUTPUT_DIR / "cleaned_jobs.csv",
    index=False,
    encoding="utf-8"
)

print("Job dataset cleaned and saved.")



resumes = resumes.drop_duplicates().copy()


resumes["Resume_str"] = resumes["Resume_str"].fillna("")


resumes["Resume_str"] = resumes["Resume_str"].apply(clean_text)


resumes["Category"] = (
    resumes["Category"]
    .fillna("Unknown")
    .astype(str)
    .str.strip()
    .str.lower()
)


resumes = resumes[
    resumes["Resume_str"].str.len() > 0
].copy()


resumes = resumes.drop_duplicates(
    subset=["Resume_str"]
).copy()


resumes.to_csv(
    OUTPUT_DIR / "cleaned_resumes.csv",
    index=False,
    encoding="utf-8"
)

print("Resume dataset cleaned and saved.")

