
import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "cleaned_data"

jobs = pd.read_csv(DATA_DIR / "cleaned_jobs.csv")
resumes = pd.read_csv(DATA_DIR / "cleaned_resumes.csv")

print("========== JOB DATA ==========")
print("Total job rows:", len(jobs))
print("Job columns:", jobs.columns.tolist())
print(jobs.head(3))

print("\n========== RESUME DATA ==========")
print("Total resume rows:", len(resumes))
print("Resume columns:", resumes.columns.tolist())
print(resumes.head(3))

print("\nMissing values in job data:")
print(jobs.isnull().sum())

print("\nMissing values in resume data:")
print(resumes.isnull().sum())
